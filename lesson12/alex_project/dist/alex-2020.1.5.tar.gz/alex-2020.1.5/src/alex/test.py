def test():
    print(__name__,"Hello.")
